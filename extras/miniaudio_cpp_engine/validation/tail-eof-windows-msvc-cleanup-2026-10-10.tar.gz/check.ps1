$ErrorActionPreference = 'Stop'
$a = 'C:\Users\codex-worker\.codex\codex-mcp-server\job-artifacts\5ed2f6c9914b1375\continuations\c6296c17279a94b8\task-0'
$old = 'C:\Users\codex-worker\.codex\codex-mcp-server\job-artifacts\5ed2f6c9914b1375\tasks\task-0'
$r = 'C:\codex-worker\offload\miniaudio-eof-2437bea'
$base = 'C:\codex-worker\repos\miniaudio-835a14f'
$env:GIT_OPTIONAL_LOCKS = '0'
$ledger = Get-Content -LiteralPath "$a\closure-ledger.json" -Raw | ConvertFrom-Json
$life = Get-Content -LiteralPath "$old\lifecycle.json" -Raw | ConvertFrom-Json
Get-Command Get-FileHash | Select-Object Name,Source,Version | ConvertTo-Json | Set-Content "$a\host-command.json"
function Identity($p) {
    $f = Get-Item -LiteralPath $p -Force
    [pscustomobject]@{path=$f.FullName;bytes=[long]$f.Length;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
}
$oldInitial = @(Get-ChildItem -LiteralPath $old -Force -File | ForEach-Object {Identity $_.FullName})
$oldInitial | ConvertTo-Json -Depth 5 | Set-Content "$a\old-evidence-before.json"
$m = Get-Content -LiteralPath "$old\manifest.json" -Raw | ConvertFrom-Json
$oldManifestHash = (Get-FileHash -LiteralPath "$old\manifest.json").Hash.ToLowerInvariant()
if ($oldManifestHash -ne $ledger.controllerVerification.manifestSha256) {throw 'Old manifest digest mismatch'}
$bad = @(foreach ($row in $m.files) {$id=Identity "$old\$($row.path)"; if ($id.sha256 -ne $row.sha256 -or $id.bytes -ne $row.bytes) {$row.path}})
if ($bad.Count -or $oldInitial.Count -ne 55) {throw 'Old evidence mismatch'}
$pathChecks = foreach ($target in $ledger.authorizedTargets) {
    if ($target -notin $life.ownedPaths) {throw 'Ownership mismatch'}
    $full = [IO.Path]::GetFullPath($target)
    if ($full -cne $target) {throw 'Noncanonical target'}
    $ancestors = @()
    $cursor = $full
    while ($cursor) {
        $item=Get-Item -LiteralPath $cursor -Force
        $ancestors += [pscustomobject]@{path=$item.FullName;attributes=$item.Attributes.ToString();linkType=$item.LinkType;target=$item.Target}
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {throw "Reparse ancestor: $cursor"}
        $parent=[IO.Directory]::GetParent($cursor)
        if ($null -eq $parent) {break}
        $cursor=$parent.FullName
    }
    $f=Get-Item -LiteralPath $full -Force
    $count=[long]0; $bytes=[long]0; $directories=[long]0
    if ($f.PSIsContainer) {
        $stack=[Collections.Generic.Stack[string]]::new(); $stack.Push($full)
        while ($stack.Count) {
            $current=$stack.Pop(); $directories++
            foreach ($child in Get-ChildItem -LiteralPath $current -Force) {
                if ($child.Attributes -band [IO.FileAttributes]::ReparsePoint) {throw "Reparse descendant: $($child.FullName)"}
                if ($child.PSIsContainer) {$stack.Push($child.FullName)} else {$count++; $bytes += [long]$child.Length}
            }
        }
    } else {$count=1; $bytes=[long]$f.Length}
    [pscustomobject]@{path=$full;declaredOwned=$true;exists=$true;canonical=$true;reparseOrMountPoints=0;ancestors=$ancestors;fileCount=$count;directoryCount=$directories;logicalBytes=$bytes}
}
$pathChecks | ConvertTo-Json -Depth 8 | Set-Content "$a\target-paths.json"
if (Test-Path -LiteralPath $ledger.quarantineCandidate) {throw 'Quarantine candidate exists; no-clobber check failed'}
$repos = @(@{path=$base;revision='835a14fc28a14d96c54f6932ee6121acfcd58a90'},@{path="$r\source";revision='2437bea582ef085621adf5b50e628f8ecede8f90'},@{path="$r\timer";revision='38d087f02dc4fb9f00a36d10fbf5ca97e02e2aa9'})
$repoChecks = foreach ($repo in $repos) {
    $head=(& git -C $repo.path rev-parse HEAD); if ($LASTEXITCODE) {throw 'git rev-parse failed'}
    $top=(& git -C $repo.path rev-parse --show-toplevel); if ($LASTEXITCODE) {throw 'git toplevel failed'}
    $status=@(& git -C $repo.path status --porcelain=v1 --untracked-files=all); if ($LASTEXITCODE) {throw 'git status failed'}
    [pscustomobject]@{path=$repo.path;head=$head;expected=$repo.revision;headMatches=($head -ceq $repo.revision);toplevel=$top;status=$status;clean=($status.Count -eq 0);optionalGitLocks='disabled'}
}
$repoChecks | ConvertTo-Json -Depth 5 | Set-Content "$a\repositories-before.json"
$bundleChecks = foreach ($b in $life.immutableInputs) {$id=Identity $b.path; if ($id.bytes -ne $b.bytes -or $id.sha256 -ne $b.sha256) {throw 'Bundle mismatch'}; $id}
$bundleChecks | ConvertTo-Json -Depth 4 | Set-Content "$a\bundle-checks.json"
$originalHashes=Get-Content -LiteralPath "$old\source-hashes-before.json" -Raw | ConvertFrom-Json
$sourceMismatch=@(foreach ($f in $originalHashes) {if ((Get-FileHash -LiteralPath "$($f.root)\$($f.path)").Hash.ToLowerInvariant() -ne $f.sha256) {$f.path}})
@{filesChecked=$originalHashes.Count;mismatches=$sourceMismatch} | ConvertTo-Json | Set-Content "$a\staged-content-check.json"
$processCheck=[ordered]@{query='Get-CimInstance Win32_Process: ExecutablePath and CommandLine to identify references to any exact target';attempts=1;scope=$ledger.authorizedTargets;conclusive=$false;status='pending';matchingProcesses=@();error=$null}
try {
    $processes=@(Get-CimInstance -ClassName Win32_Process -Property ProcessId,ExecutablePath,CommandLine -ErrorAction Stop)
    $processCheck.status='query_returned_requires_completeness_and_locker_review'
    $processCheck.matchingProcesses=@(foreach ($p in $processes) {foreach ($target in $ledger.authorizedTargets) {if (($p.ExecutablePath -and $p.ExecutablePath.StartsWith($target,[StringComparison]::OrdinalIgnoreCase)) -or ($p.CommandLine -and $p.CommandLine.IndexOf($target,[StringComparison]::OrdinalIgnoreCase) -ge 0)) {[pscustomobject]@{pid=$p.ProcessId;target=$target};break}}})
    $processCheck['returnedCount']=$processes.Count
    $processCheck['missingExecutablePathCount']=@($processes | Where-Object {-not $_.ExecutablePath}).Count
} catch {
    $processCheck.status='required_process_query_failed'
    $processCheck.error=@{message=$_.Exception.Message;fullyQualifiedErrorId=$_.FullyQualifiedErrorId;category=$_.CategoryInfo.ToString();hresult=$_.Exception.HResult}
}
$processCheck | ConvertTo-Json -Depth 6 | Set-Content "$a\process-check.json"
@{targetMutationPerformed=$false;quarantineExists=(Test-Path -LiteralPath $ledger.quarantineCandidate);requiredProcessCheck=$processCheck;logicalBytesRetained=[long](($pathChecks | Measure-Object logicalBytes -Sum).Sum);freeBytes=[IO.DriveInfo]::new('C:\').AvailableFreeSpace} | ConvertTo-Json -Depth 7 | Set-Content "$a\check-result.json"
Get-Content -LiteralPath "$a\check-result.json"
