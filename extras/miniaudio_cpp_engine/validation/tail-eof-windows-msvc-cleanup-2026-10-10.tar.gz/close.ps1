$ErrorActionPreference='Stop'
$a='C:\Users\codex-worker\.codex\codex-mcp-server\job-artifacts\5ed2f6c9914b1375\continuations\c6296c17279a94b8\task-0'
$old='C:\Users\codex-worker\.codex\codex-mcp-server\job-artifacts\5ed2f6c9914b1375\tasks\task-0'
$env:GIT_OPTIONAL_LOCKS='0'
$ledger=Get-Content -LiteralPath "$a\closure-ledger.json" -Raw | ConvertFrom-Json
$process=Get-Content -LiteralPath "$a\process-check.json" -Raw | ConvertFrom-Json
if ($process.status -ne 'required_process_query_failed') {throw 'Closure requires recorded blocker; no deletion is implemented by this evidence script'}
$paths=Get-Content -LiteralPath "$a\target-paths.json" -Raw | ConvertFrom-Json
$before=Get-Content -LiteralPath "$a\repositories-before.json" -Raw | ConvertFrom-Json
$after=foreach($repo in $before) {
    $head=& git -C $repo.path rev-parse HEAD; if($LASTEXITCODE){throw 'HEAD query failed'}
    $status=@(& git -C $repo.path status --porcelain=v1 --untracked-files=all); if($LASTEXITCODE){throw 'Status query failed'}
    [pscustomobject]@{path=$repo.path;head=$head;expected=$repo.expected;headMatches=($head -ceq $repo.expected);status=$status;clean=($status.Count -eq 0);unchangedSincePrecheck=($head -ceq $repo.head -and ($status -join "`n") -ceq ($repo.status -join "`n"))}
}
$after | ConvertTo-Json -Depth 5 | Set-Content "$a\repositories-after.json"
$sourceCheck=Get-Content -LiteralPath "$a\staged-content-check.json" -Raw | ConvertFrom-Json
$bundleBefore=Get-Content -LiteralPath "$a\bundle-checks.json" -Raw | ConvertFrom-Json
$bundleAfter=foreach($b in $bundleBefore){$f=Get-Item -LiteralPath $b.path;$hash=(Get-FileHash -LiteralPath $b.path).Hash.ToLowerInvariant();@{path=$b.path;bytes=[long]$f.Length;sha256=$hash;unchanged=($hash -ceq $b.sha256 -and [long]$f.Length -eq [long]$b.bytes)}}
$oldBefore=Get-Content -LiteralPath "$a\old-evidence-before.json" -Raw | ConvertFrom-Json
$oldNow=@(Get-ChildItem -LiteralPath $old -Recurse -Force -File)
$oldDifferences=@(foreach($row in $oldBefore){$f=Get-Item -LiteralPath $row.path;if([long]$f.Length -ne [long]$row.bytes -or (Get-FileHash -LiteralPath $f.FullName).Hash.ToLowerInvariant() -cne $row.sha256){$row.path}})
if($oldNow.Count -ne $oldBefore.Count -or $oldDifferences.Count){throw 'Old evidence changed'}
$m=Get-Content -LiteralPath "$old\manifest.json" -Raw | ConvertFrom-Json
$seal=Get-Content -LiteralPath "$old\manifest.seal.json" -Raw | ConvertFrom-Json
$manifestHash=(Get-FileHash -LiteralPath "$old\manifest.json").Hash.ToLowerInvariant()
$oldSum=[long]0; foreach($row in $m.files){$oldSum += [long]$row.bytes}
if($manifestHash -cne $ledger.controllerVerification.manifestSha256 -or $seal.manifestSha256 -cne $manifestHash -or $oldSum -ne [long]$m.payloadBytes -or $seal.payloadBytes -ne $oldSum -or $seal.rowCount -ne $m.files.Count){throw 'Old seal mismatch'}
@{allOldFilesUnchanged=$true;oldFileCount=$oldNow.Count;manifestSha256=$manifestHash;sealSha256=(Get-FileHash -LiteralPath "$old\manifest.seal.json").Hash.ToLowerInvariant();payloadRows=$m.files.Count;payloadBytes=$oldSum;oldSealUnchanged=$true;oldLifecycleUnchanged=$true} | ConvertTo-Json | Set-Content "$a\old-evidence-after.json"
$retained=@(foreach($p in $paths){@{path=$p.path;exists=(Test-Path -LiteralPath $p.path);logicalBytes=[long]$p.logicalBytes;fileCount=[long]$p.fileCount;state='retained_blocked_process_locker_visibility'}})
$retainedBytes=[long]0; foreach($p in $retained){$retainedBytes += [long]$p.logicalBytes}
$free=[long][IO.DriveInfo]::new('C:\').AvailableFreeSpace
$cleanup=[ordered]@{
 identity=$ledger.identity
 outcome='blocked_no_removal'
 scope=$ledger.authorizedTargets
 removedPaths=@()
 retainedTargets=$retained
 logicalBytesRemoved=[long]0
 logicalBytesRetained=$retainedBytes
 volumeFreeBytesBefore=[long]$ledger.volumeFreeBytesBefore
 volumeFreeBytesAfter=$free
 observedFreeByteDelta=[long]($free - [long]$ledger.volumeFreeBytesBefore)
 freeByteDeltaInterpretation='Observed volume change includes continuation evidence and unrelated host activity; no bytes reclaimed by cleanup.'
 estimatedPeakExtraBytes=[long]$ledger.estimatedPeakExtraBytes
 coexistenceCredible=($free -gt [long]$ledger.estimatedPeakExtraBytes)
 canonicalPathsNoReparseOrMountPoints=$true
 exactOwnershipVerifiedAgainstOldLifecycle=$true
 quarantineCandidate=$ledger.quarantineCandidate
 quarantineExists=(Test-Path -LiteralPath $ledger.quarantineCandidate)
 renameCount=0
 deletionCount=0
 processCheck=$process
 lockerCheck=@{conclusive=$false;status='not_established';reason='Required process visibility denied. Historical Restart Manager denial known; no retry or bypass; no alternate delete criterion used.'}
 stagedSourceHashes=$sourceCheck
 repositoriesAfter=$after
 bundlesAfter=$bundleAfter
 oldEvidence=@{all55FilesUnchanged=$true;manifestSha256=$manifestHash;sealUnchanged=$true;payloadRows=53;payloadBytes=[long]16234550}
 controllerVerification=$ledger.controllerVerification
 nextValidAction='Controller-supported host maintenance must establish conclusive process/locker visibility for every target, then a cleanup continuation must recheck ownership, paths, Git state and hashes before exact no-clobber quarantine/removal. No worker escalation or ACL changes authorized.'
 reviewDate='2026-10-11'
 reproducibility=@{miniaudio='2437bea582ef085621adf5b50e628f8ecede8f90';timer='38d087f02dc4fb9f00a36d10fbf5ca97e02e2aa9';basePrerequisite='835a14fc28a14d96c54f6932ee6121acfcd58a90';bundles='Both exact immutable input bundles retained with verified original hashes; miniaudio incremental bundle requires base prerequisite; timer full Git history retains historical LFS pointers.';nativeValidation='Previously sealed MSVC Debug x64 engine 5/5 and installed consumer 1/1; no tests executed in this continuation.'}
 artifactDirectories='All retained; old sealed directory read-only; only new continuation evidence written.'
 forbiddenTargetsTouched=$false
}
$cleanup | ConvertTo-Json -Depth 12 | Set-Content "$a\cleanup.json"
# The manifest excludes only itself and its digest seal. Use explicit ordinal ordering.
$files=@(Get-ChildItem -LiteralPath $a -Recurse -Force -File | Where-Object {$_.Name -notin @('manifest.json','manifest.seal.json')})
$names=[string[]]@($files | ForEach-Object {[IO.Path]::GetRelativePath($a,$_.FullName).Replace('\','/')})
[Array]::Sort($names,[StringComparer]::Ordinal)
$seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$rows=@(foreach($name in $names){if(-not $seen.Add($name)){throw 'Duplicate payload path'};$f=Get-Item -LiteralPath "$a\$name";[ordered]@{path=$name;bytes=[long]$f.Length;sha256=(Get-FileHash -LiteralPath $f.FullName).Hash.ToLowerInvariant()}})
$sum=[long]0;foreach($row in $rows){$sum += [long]$row.bytes}
[ordered]@{algorithm='SHA256';sorting='Relative paths, forward slashes, StringComparer.Ordinal (case-sensitive ordinal)';rowCount=$rows.Count;payloadBytes=$sum;files=$rows} | ConvertTo-Json -Depth 5 | Set-Content "$a\manifest.json"
$written=Get-Content -LiteralPath "$a\manifest.json" -Raw | ConvertFrom-Json
$inventory=@(Get-ChildItem -LiteralPath $a -Recurse -Force -File | Where-Object {$_.Name -notin @('manifest.json','manifest.seal.json')})
$inventorySum=[long]0;foreach($f in $inventory){$inventorySum += [long]$f.Length}
$inventoryNames=[string[]]@($inventory | ForEach-Object {[IO.Path]::GetRelativePath($a,$_.FullName).Replace('\','/')})
[Array]::Sort($inventoryNames,[StringComparer]::Ordinal)
if($inventory.Count -ne $written.rowCount -or $inventorySum -ne [long]$written.payloadBytes -or ($inventoryNames -join "`n") -cne ($written.files.path -join "`n")){throw 'Inventory mismatch'}
$checkedSum=[long]0
foreach($row in $written.files){$f=Get-Item -LiteralPath "$a\$($row.path)";if([long]$f.Length -ne [long]$row.bytes -or (Get-FileHash -LiteralPath $f.FullName).Hash.ToLowerInvariant() -cne $row.sha256){throw 'Payload verification failed'};$checkedSum += [long]$row.bytes}
if($checkedSum -ne [long]$written.payloadBytes){throw 'Payload aggregate mismatch'}
$newSeal=[ordered]@{manifestSha256=(Get-FileHash -LiteralPath "$a\manifest.json").Hash.ToLowerInvariant();rowCount=$written.rowCount;payloadBytes=[long]$written.payloadBytes;sorting=$written.sorting;uniquePaths=$true;inventoryAndBytesVerified=$true;everyPayloadHashVerified=$true;aggregateArithmetic='Int64';controllerRetrieval='pending for new continuation'}
$newSeal | ConvertTo-Json | Set-Content "$a\manifest.seal.json"
$newSeal | ConvertTo-Json
$cleanup | Select-Object outcome,logicalBytesRemoved,logicalBytesRetained,volumeFreeBytesBefore,volumeFreeBytesAfter,observedFreeByteDelta | ConvertTo-Json
