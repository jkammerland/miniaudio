import os, sys, json, hashlib, pathlib, subprocess, stat, ctypes, shutil, datetime

A = pathlib.Path('/Users/ai-dev/.codex/codex-mcp-server/job-artifacts/2d78782e802f5c36/continuations/39180ff0d55f90c8/task-0')
OLD = pathlib.Path('/Users/ai-dev/.codex/codex-mcp-server/job-artifacts/2d78782e802f5c36/tasks/task-0')
BASE = pathlib.Path('/Users/ai-dev/repos/miniaudio-835a14f')
R = pathlib.Path('/Users/ai-dev/offload/miniaudio-eof-2437bea')
Q = pathlib.Path('/Users/ai-dev/offload/miniaudio-eof-2437bea.cleanup-39180ff0d55f90c8')
TARGETS = [R, pathlib.Path('/Users/ai-dev/offload/incoming/miniaudio-eof-2437bea.bundle'), pathlib.Path('/Users/ai-dev/offload/incoming/timer-miniaudio-eof-2437bea.bundle')]

def save(name, value):
    (A/name).write_text(json.dumps(value, indent=2)+'\n')

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def free():
    s = os.statvfs(R.parent)
    return s.f_bavail*s.f_frsize

def run(name, argv, cwd=BASE, allowed=(0,)):
    p = subprocess.run([str(a) for a in argv], cwd=cwd, capture_output=True, text=True, env=dict(os.environ, GIT_OPTIONAL_LOCKS='0'))
    record = {'name':name, 'argv':[str(a) for a in argv], 'cwd':str(cwd), 'exitCode':p.returncode, 'stdout':p.stdout, 'stderr':p.stderr}
    with (A/'commands.jsonl').open('a') as f:
        f.write(json.dumps(record)+'\n')
    assert p.returncode in allowed, record
    return p

def verify_old():
    assert digest(OLD/'manifest.json') == 'cd71d50757d6472d55a39b5f02c1bfad0c469e227157b3305d0fa9d4f55d5768'
    m = json.loads((OLD/'manifest.json').read_text())
    inventory = sorted(p.relative_to(OLD).as_posix() for p in OLD.rglob('*') if p.is_file())
    assert inventory == sorted([r['path'] for r in m['files']]+['manifest.json','manifest.sha256'])
    assert len(m['files']) == len({r['path'] for r in m['files']}) == 81
    assert [r['path'] for r in m['files']] == sorted(r['path'] for r in m['files'])
    assert sum(r['bytes'] for r in m['files']) == m['payloadBytes'] == 300964
    for r in m['files']:
        p = OLD/r['path']
        assert p.stat().st_size == r['bytes'] and digest(p) == r['sha256']
    assert (OLD/'manifest.sha256').read_text() == digest(OLD/'manifest.json')+'  manifest.json\n'
    return {'unchanged':True,'totalFiles':83,'payloadRows':81,'payloadBytes':300964,'manifestSha256':digest(OLD/'manifest.json'),'ledgerSha256':digest(OLD/'lifecycle.json')}

def repo(name, p, revision):
    h = run(name+'-head', ['git','rev-parse','HEAD'],p).stdout.strip()
    s = run(name+'-status', ['git','status','--porcelain=v1','--untracked-files=all'],p).stdout
    assert h == revision and not s
    return {'path':str(p),'head':h,'clean':True}

def pathcheck(p):
    for a in [p]+list(p.parents):
        assert not a.is_symlink(), 'symlink in target/ancestor: '+str(a)
    assert str(p.resolve(strict=True)) == str(p)
    assert not os.path.ismount(p)
    assert p.lstat().st_uid == os.getuid()

def inventory(p):
    pathcheck(p)
    device = p.lstat().st_dev
    entries = [p]
    if p.is_dir():
        for root, dirs, files in os.walk(p, followlinks=False, onerror=lambda e: (_ for _ in ()).throw(e)):
            entries.extend(pathlib.Path(root)/f for f in dirs+files)
    total = 0
    links = []
    regular = 0
    inode_ids = set()
    for q in entries:
        s = q.lstat()
        assert s.st_uid == os.getuid(), 'foreign owner: '+str(q)
        assert s.st_dev == device and not os.path.ismount(q), 'mount crossing: '+str(q)
        assert stat.S_ISDIR(s.st_mode) or stat.S_ISREG(s.st_mode) or stat.S_ISLNK(s.st_mode), 'special file: '+str(q)
        if stat.S_ISREG(s.st_mode):
            regular += 1
            total += s.st_size
            inode_ids.add((s.st_dev,s.st_ino))
        elif stat.S_ISLNK(s.st_mode):
            links.append({'path':str(q),'target':os.readlink(q)})
    return {'path':str(p),'uid':os.getuid(),'device':device,'inode':p.lstat().st_ino,'entries':len(entries),'regularFiles':regular,'uniqueRegularInodes':len(inode_ids),'logicalRegularFileBytes':total,'symlinks':links,'symlinkPolicy':'internal symlinks unlinked without following; all targets and ancestors are non-symlinks','mountCrossings':False}

def opencheck(p, name):
    args = ['/usr/sbin/lsof','-nP'] + (['+D',p] if p.is_dir() else ['--',p])
    result = run(name,args,allowed=(0,1))
    assert result.returncode == 1 and not result.stdout.strip() and not result.stderr.strip(), 'open-file check not conclusively empty: '+str(p)
    return {'path':str(p),'exitCode':1,'stdoutEmpty':True,'stderrEmpty':True,'result':'no open files/cwd/references reported by native lsof; no query errors'}

def preflight():
    assert pathlib.Path.cwd() == BASE
    assert not os.path.lexists(Q)
    l = json.loads((OLD/'lifecycle.json').read_text())
    assert l['ownedRoot'] == str(R)
    assert [b['path'] for b in l['immutableInputBundles']] == [str(p) for p in TARGETS[1:]]
    out = {'oldEvidence':verify_old(),'freeBytes':free(),'workingDirectory':str(pathlib.Path.cwd()),'ledgerOwnershipMatches':True}
    out['base'] = repo('base-before',BASE,'835a14fc28a14d96c54f6932ee6121acfcd58a90')
    out['source'] = repo('source-before',R/'source','2437bea582ef085621adf5b50e628f8ecede8f90')
    out['timer'] = repo('timer-before',R/'timer','38d087f02dc4fb9f00a36d10fbf5ca97e02e2aa9')
    out['bundles'] = []
    for b in l['immutableInputBundles']:
        p = pathlib.Path(b['path'])
        assert p.stat().st_size == b['bytes'] and digest(p) == b['sha256']
        out['bundles'].append(b)
    out['targets'] = [inventory(p) for p in TARGETS]
    mounts = run('mounts',['/sbin/mount']).stdout
    for line in mounts.splitlines():
        if ' on ' in line:
            point = line.split(' on ',1)[1].rsplit(' (',1)[0]
            for p in TARGETS:
                assert point != str(p) and not point.startswith(str(p)+'/'), 'mounted target: '+line
    out['mountTableChecked'] = True
    # Retain only relevant process rows; never persist unrelated process arguments.
    ps = subprocess.run(['/bin/ps','-axo','pid=,uid=,command='],capture_output=True,text=True)
    assert ps.returncode == 0 and not ps.stderr.strip(), 'process query failed'
    matches = [line for line in ps.stdout.splitlines() if any(str(p) in line for p in TARGETS+[Q])]
    out['processReferences'] = matches
    save('process-check.json',{'command':['/bin/ps','-axo','pid=,uid=,command='],'exitCode':ps.returncode,'matchingRows':matches,'stderr':ps.stderr})
    assert not matches, 'process references require review'
    out['openFiles'] = [opencheck(p,'lsof-'+str(i)) for i,p in enumerate(TARGETS)]
    save('preflight.json',out)
    print(json.dumps(out,indent=2))

def cleanup():
    pre = json.loads((A/'preflight.json').read_text())
    assert pathlib.Path.cwd() == BASE and not os.path.lexists(Q)
    verify_old()
    # Revalidate exact ownership/identity and open-file state immediately before mutation.
    for i,p in enumerate(TARGETS):
        current = inventory(p)
        assert current == pre['targets'][i]
        opencheck(p,'lsof-final-'+str(i))
    before = free()
    result = {'freeBytesBefore':before,'logicalBytesDefinition':'sum of regular-file st_size for removed paths; excludes directory metadata and symlink payload sizes','removed':[],'retained':[],'quarantine':str(Q),'reviewDate':'2026-10-11'}
    save('cleanup.json',dict(result,state='checks_passed_before_rename'))
    # Darwin renamex_np RENAME_EXCL prevents replacement even if quarantine appears concurrently.
    libc = ctypes.CDLL('/usr/lib/libSystem.B.dylib',use_errno=True)
    fn = libc.renamex_np
    fn.argtypes = [ctypes.c_char_p,ctypes.c_char_p,ctypes.c_uint]
    fn.restype = ctypes.c_int
    rc = fn(os.fsencode(R),os.fsencode(Q),0x00000004)
    if rc != 0:
        raise OSError(ctypes.get_errno(),'exclusive quarantine rename failed')
    assert not os.path.lexists(R)
    pathcheck(Q)
    assert Q.lstat().st_ino == pre['targets'][0]['inode']
    opencheck(Q,'lsof-quarantine')
    assert shutil.rmtree.avoids_symlink_attacks
    shutil.rmtree(Q)
    assert not os.path.lexists(Q)
    result['removed'].append({'path':str(R),'logicalBytes':pre['targets'][0]['logicalRegularFileBytes']})
    for i,p in enumerate(TARGETS[1:],1):
        pathcheck(p)
        assert p.lstat().st_ino == pre['targets'][i]['inode']
        assert digest(p) == pre['bundles'][i-1]['sha256']
        opencheck(p,'lsof-before-unlink-'+str(i))
        p.unlink()
        assert not os.path.lexists(p)
        result['removed'].append({'path':str(p),'logicalBytes':pre['targets'][i]['logicalRegularFileBytes']})
    result['exactPathsAbsent'] = {str(p):not os.path.lexists(p) for p in TARGETS+[Q]}
    assert all(result['exactPathsAbsent'].values())
    result['baseAfter'] = repo('base-after',BASE,'835a14fc28a14d96c54f6932ee6121acfcd58a90')
    result['stagingAfter'] = {'source':'absent, removed with authorized staging root','timer':'absent, removed with authorized staging root'}
    result['oldEvidenceAfter'] = verify_old()
    result['freeBytesAfter'] = free()
    result['observedFreeByteDelta'] = result['freeBytesAfter']-before
    result['logicalBytesRemoved'] = sum(r['logicalBytes'] for r in result['removed'])
    result['reproducibility'] = 'Source staging reproducible from recorded immutable commits/bundles and prerequisite. Generated binaries/install outputs can be rebuilt with recorded configuration/toolchain; bit-for-bit binary identity is not asserted. Bundles are deleted locally; reconstruction requires controller-retained immutable inputs or equivalent Git objects.'
    result['retainedEvidenceDirectories'] = [str(OLD),str(A)]
    result['cleanupState'] = 'complete'
    result['freeByteDeltaCaveat'] = 'Observed volume delta is independent of logical bytes and can include APFS accounting or concurrent system activity.'
    save('cleanup.json',result)
    print(json.dumps(result,indent=2))

def seal():
    c = json.loads((A/'cleanup.json').read_text())
    assert c['cleanupState'] == 'complete'
    assert all(not os.path.lexists(p) for p in TARGETS+[Q])
    verify_old()
    paths = sorted(p for p in A.rglob('*') if p.is_file() and p.name not in ['manifest.json','manifest.sha256'])
    rows = [{'path':p.relative_to(A).as_posix(),'bytes':p.stat().st_size,'sha256':digest(p)} for p in paths]
    save('manifest.json',{'algorithm':'SHA256','rowCount':len(rows),'payloadBytes':sum(r['bytes'] for r in rows),'files':rows})
    m = json.loads((A/'manifest.json').read_text())
    actual = sorted(p.relative_to(A).as_posix() for p in A.rglob('*') if p.is_file() and p.name not in ['manifest.json','manifest.sha256'])
    assert actual == [r['path'] for r in m['files']]
    assert len(actual) == len(set(actual)) == m['rowCount']
    assert sum((A/p).stat().st_size for p in actual) == m['payloadBytes']
    for r in m['files']:
        assert digest(A/r['path']) == r['sha256'] and (A/r['path']).stat().st_size == r['bytes']
    h = digest(A/'manifest.json')
    (A/'manifest.sha256').write_text(h+'  manifest.json\n')
    print('SEALED',h,m['rowCount'],m['payloadBytes'])

if __name__ == '__main__':
    {'preflight':preflight,'cleanup':cleanup,'seal':seal}[sys.argv[1]]()
