from cleanup_driver import *

# The first root lsof query is preserved and is not retried or bypassed.
records = [json.loads(s) for s in (A/'commands.jsonl').read_text().splitlines()]
root_check = next(r for r in records if r['name'] == 'lsof-0')
checks = [root_check]
for i, p in enumerate(TARGETS[1:], 1):
    run('lsof-bundle-'+str(i), ['/usr/sbin/lsof','-nP','--',p], allowed=(0,1))
records = [json.loads(s) for s in (A/'commands.jsonl').read_text().splitlines()]
checks.extend(r for r in records if r['name'].startswith('lsof-bundle-'))
assert len(checks) == 3
assert all(r['stderr'].strip() for r in checks)
old = verify_old()
inv = [inventory(p) for p in TARGETS]
l = json.loads((OLD/'lifecycle.json').read_text())
for b in l['immutableInputBundles']:
    p = pathlib.Path(b['path'])
    assert p.stat().st_size == b['bytes'] and digest(p) == b['sha256']
sources = {
    'base':repo('base-after-retention', BASE, '835a14fc28a14d96c54f6932ee6121acfcd58a90'),
    'source':repo('source-after-retention', R/'source', '2437bea582ef085621adf5b50e628f8ecede8f90'),
    'timer':repo('timer-after-retention', R/'timer', '38d087f02dc4fb9f00a36d10fbf5ca97e02e2aa9')
}
next_action = 'Controller must arrange resolution of the native lsof NFS stat warning (or provide an authorized conclusive native open-file query), then request cleanup continuation with fresh ownership/path/process/open-file checks. No target deletion is authorized by an inconclusive query; no escalation or NFS/user-data changes were attempted.'
free_after = free()
free_before = json.loads((A/'lifecycle.json').read_text())['volumeFreeBytesSnapshot']
save('preflight.json', {
    'ownership': 'Exact authorized paths match immutable previous ledger and caller authorization; every entry owned by ai-dev uid 502',
    'targets': inv,
    'canonicalTargetAndAncestorPathsNoSymlinks':True,
    'mountCrossings':False,
    'internalSymlinks':'Generated runtime-library symlinks recorded, not followed; referents never in deletion scope',
    'processCheck':'No process command rows referenced exact targets; see process-check.json',
    'openFileChecks':checks,
    'sourceAndBaseChecks':sources,
    'bundleHashChecks':l['immutableInputBundles'],
    'oldEvidence':old,
    'outcome':'inconclusive_open_file_checks_all_targets_retained'
})
absent = {str(p):not os.path.lexists(p) for p in TARGETS+[Q]}
assert all(not absent[str(p)] for p in TARGETS) and absent[str(Q)]
save('cleanup.json', {
    'cleanupState':'retained_open_file_check_inconclusive',
    'removed':[],
    'retained':[str(p) for p in TARGETS],
    'retainedEvidenceDirectories':[str(OLD),str(A)],
    'quarantineTarget':str(Q),
    'quarantineCreated':False,
    'exactPathsAbsent':absent,
    'cleanupMutationsPerformed':False,
    'logicalBytesRemoved':0,
    'logicalRegularFileBytesRetained':sum(i['logicalRegularFileBytes'] for i in inv),
    'logicalBytesDefinition':'Sum of regular-file st_size; excludes directory metadata and symlink payload sizes',
    'freeBytesBefore':free_before,
    'freeBytesAfter':free_after,
    'observedFreeByteDelta':free_after-free_before,
    'freeByteDeltaCaveat':'Volume-wide change during read-only checks and new evidence writes; no cleanup space was reclaimed',
    'sourceAndBaseAfter':sources,
    'oldEvidenceAfter':old,
    'reason':'Every exact-target lsof query warns that an NFS filesystem cannot be stat-ed and output may be incomplete; no conclusive absence of open files/locks',
    'nextAction':next_action,
    'reproducibility':'No material removed. Staging source is reproducible from the recorded immutable commits/bundles and prerequisite; bundles remain locally retained. Build outputs are rebuildable from recorded toolchain/configuration; bit-for-bit reproducibility is not asserted.',
    'reviewDate':'2026-10-11'
})
save('.codex-result.json', {
    'category':'infrastructure_failure',
    'summary':'Cleanup withheld: all exact-target lsof queries reported incomplete output due to an NFS stat warning; every authorized target retained unchanged.',
    'attemptedPaths':[str(p) for p in TARGETS],
    'resolvedExecutables':{'lsof':'/usr/sbin/lsof'},
    'selectedEnvironment':'mac-offload, isolated ai-dev account',
    'sourceRevision':'2437bea582ef085621adf5b50e628f8ecede8f90',
    'remediation':[next_action]
})
# Seal a truthful retained-target outcome after explicitly checking absence/presence.
# The cleanup is not represented as complete.
assert verify_old() == old
paths = sorted(p for p in A.rglob('*') if p.is_file() and p.name not in ['manifest.json','manifest.sha256'])
rows = [{'path':p.relative_to(A).as_posix(),'bytes':p.stat().st_size,'sha256':digest(p)} for p in paths]
save('manifest.json', {'algorithm':'SHA256','rowCount':len(rows),'payloadBytes':sum(r['bytes'] for r in rows),'files':rows})
m = json.loads((A/'manifest.json').read_text())
actual = sorted(p.relative_to(A).as_posix() for p in A.rglob('*') if p.is_file() and p.name not in ['manifest.json','manifest.sha256'])
assert actual == [r['path'] for r in m['files']]
assert len(actual) == len(set(actual)) == m['rowCount']
assert sum((A/p).stat().st_size for p in actual) == m['payloadBytes']
for r in m['files']:
    assert digest(A/r['path']) == r['sha256'] and (A/r['path']).stat().st_size == r['bytes']
h = digest(A/'manifest.json')
(A/'manifest.sha256').write_text(h+'  manifest.json\n')
print(json.dumps(json.loads((A/'cleanup.json').read_text()),indent=2))
print('SEALED',h,m['rowCount'],m['payloadBytes'])
