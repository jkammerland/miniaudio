$ErrorActionPreference='Stop'
$a='C:\Users\codex-worker\.codex\codex-mcp-server\job-artifacts\5ed2f6c9914b1375\tasks\task-0'
$r='C:\codex-worker\offload\miniaudio-eof-2437bea'
Start-Transcript "$a\staging-final.log"
$env:GIT_LFS_SKIP_SMUDGE='1'
& git -C "$r\timer" checkout --detach -f 38d087f02dc4fb9f00a36d10fbf5ca97e02e2aa9
if($LASTEXITCODE){throw 'checkout'}
$state=foreach($p in @("$r\source","$r\timer",'C:\codex-worker\repos\miniaudio-835a14f')){$head=& git -C $p rev-parse HEAD;$status=@(& git -C $p status --porcelain=v1);if($status.Count){throw "dirty $p"};@{path=$p;head=$head;status=$status}}
$state | ConvertTo-Json -Depth 5 | Set-Content "$a\source-before.json"
$hashes=foreach($p in @("$r\source","$r\timer")){foreach($rel in (& git -C $p ls-files)){ $f=Get-Item -LiteralPath "$p\$rel";@{root=$p;path=$rel;bytes=$f.Length;sha256=(Get-FileHash -LiteralPath $f.FullName).Hash.ToLower()} }}
$hashes | ConvertTo-Json -Depth 4 | Set-Content "$a\source-hashes-before.json"
Stop-Transcript
