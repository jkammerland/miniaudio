@echo off
call "C:\Program Files\Microsoft Visual Studio\2026\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=amd64
if errorlevel 1 exit /b 1
"C:\Program Files\PowerShell\7\pwsh.exe" -NoProfile -NonInteractive -File "C:\Users\codex-worker\.codex\codex-mcp-server\job-artifacts\5ed2f6c9914b1375\tasks\task-0\validate.ps1"
exit /b %errorlevel%
