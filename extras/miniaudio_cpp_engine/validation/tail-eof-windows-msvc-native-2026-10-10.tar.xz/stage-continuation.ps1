$ErrorActionPreference='Stop'
$a='C:\Users\codex-worker\.codex\codex-mcp-server\job-artifacts\5ed2f6c9914b1375\tasks\task-0'
$r='C:\codex-worker\offload\miniaudio-eof-2437bea'
Start-Transcript "$a\staging-continuation.log"
& git -C "$r\source" fetch C:\codex-worker\offload\incoming\miniaudio-eof-2437bea.bundle refs/heads/feat/cpp-engine-contract;if($LASTEXITCODE){throw 'fetch'}
& git -C "$r\source" checkout --detach 2437bea582ef085621adf5b50e628f8ecede8f90;if($LASTEXITCODE){throw 'checkout'}
& git clone --branch fix/miniaudio-latest-pr-stack C:\codex-worker\offload\incoming\timer-miniaudio-eof-2437bea.bundle "$r\timer";if($LASTEXITCODE){throw 'clone'}
& git -C "$r\timer" checkout --detach 38d087f02dc4fb9f00a36d10fbf5ca97e02e2aa9;if($LASTEXITCODE){throw 'checkout'}
foreach($p in @("$r\source","$r\timer")){& git -C $p rev-parse HEAD;$s=& git -C $p status --porcelain=v1;if($s){throw "Dirty $p"}}
Stop-Transcript
