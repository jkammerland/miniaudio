$ErrorActionPreference='Stop'
$a='C:\Users\codex-worker\.codex\codex-mcp-server\job-artifacts\5ed2f6c9914b1375\tasks\task-0'
$r='C:\codex-worker\offload\miniaudio-eof-2437bea'
$before=Get-Content "$a\source-hashes-before.json" -Raw | ConvertFrom-Json
$changed=@(foreach($row in $before){$h=(Get-FileHash -LiteralPath "$($row.root)\$($row.path)").Hash.ToLower();if($h -ne $row.sha256){$row.path}})
$state=foreach($p in @("$r\source","$r\timer",'C:\codex-worker\repos\miniaudio-835a14f')){$head=& git -C $p rev-parse HEAD;$status=@(& git -C $p status --porcelain=v1);@{path=$p;head=$head;status=$status};if($status.Count){throw "dirty $p"}}
@{repositories=$state;filesRehashed=$before.Count;changedFiles=$changed} | ConvertTo-Json -Depth 6 | Set-Content "$a\source-after.json"
if($changed.Count){throw 'Source hashes changed'}
$trace=Get-Content "$a\configure-trace.jsonl" | ForEach-Object {ConvertFrom-Json $_}
$fetch=@($trace | Where-Object { $_.cmd -match '^(FetchContent_|ExternalProject_Add)' -or ($_.cmd -eq 'file' -and $_.args[0] -eq 'DOWNLOAD') -or ($_.cmd -eq 'execute_process' -and ($_.args -join ' ') -match '(git (clone|fetch|pull)|curl|wget)') })
@{prohibition='No dependency acquisition/downloads, tool installs/updates, vendoring, or replacement tool/cache copies authorized. Input bundle Git staging is local only.';executedTraceCommands=@($trace | Where-Object cmd).Count;dependencyFetchInvocations=$fetch.Count;matches=$fetch;fetchLibopus='OFF';fetchLibvorbis='OFF';timerOverride='';timerVerification='ON';auditScope='Expanded executed CMake configure trace: FetchContent, ExternalProject_Add, file DOWNLOAD, and downloader/Git acquisition execute_process commands';timerLfs='Historical benchmark observations remain exact committed LFS pointers; initial smudge adapter failed against local bundle; no LFS payload obtained; headers are ordinary Git files.'} | ConvertTo-Json -Depth 10 | Set-Content "$a\dependency-audit.json"
if($fetch.Count){throw 'Unexpected dependency fetch'}
Copy-Item "$r\consumer\CMakeFiles\installed_consumer.dir\flags.make" "$a\consumer-flags.make"
Copy-Item "$r\consumer\CMakeFiles\installed_consumer.dir\main.cpp.obj.d" "$a\consumer-header-dependencies.txt"
Copy-Item "$r\consumer\CMakeFiles\installed_consumer.dir\build.make" "$a\consumer-build.make"
$headers=@(Get-Content "$a\consumer-header-dependencies.txt" | Where-Object {$_ -match 'miniaudio'})
$badHeaders=@($headers | Where-Object { -not $_.StartsWith(($r.Replace('\','/')+'/installed prefix/include/miniaudio/')) })
if($badHeaders.Count){throw 'Noninstalled miniaudio header'}
$cache=Get-Content "$a\consumer-CMakeCache.txt"
$archives=@($cache | Where-Object {$_ -match '^_(engine|audio)_archive:FILEPATH='})
if($archives.Count -ne 2 -or @($archives | Where-Object {$_ -notlike '*installed prefix/lib/*'}).Count){throw 'archive mismatch'}
@{fixture="$r\source\extras\miniaudio_cpp_engine\tests\installed_consumer";headers=$headers;archiveCacheEntries=$archives;noninstalledMiniaudioHeaders=$badHeaders;compilerSame=$true;physicalDeviceOpened=$false;coverage=@('legacy callbacks','finite-source final caching','graceful request API')} | ConvertTo-Json -Depth 4 | Set-Content "$a\consumer-audit.json"
$identities=foreach($p in @((Get-ChildItem "$r\build\extras\miniaudio_cpp_engine" -Filter '*.exe').FullName)+@("$r\consumer\installed_consumer.exe")+@((Get-ChildItem "$r\installed prefix" -Recurse -File).FullName)){$f=Get-Item -LiteralPath $p;@{path=$f.FullName;bytes=$f.Length;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLower()}}
$identities | ConvertTo-Json -Depth 4 | Set-Content "$a\binary-and-install-identities.json"
$extraTools=foreach($p in @('C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe','C:\Windows\System32\cmd.exe','C:\Program Files (x86)\Windows Kits\10\bin\10.0.26100.0\x64\rc.exe','C:\Program Files (x86)\Windows Kits\10\bin\10.0.26100.0\x64\mt.exe','C:\Program Files\Microsoft Visual Studio\2026\BuildTools\Common7\Tools\VsDevCmd.bat')){$f=Get-Item $p;@{path=$f.FullName;bytes=$f.Length;version=$f.VersionInfo.FileVersion;sha256=(Get-FileHash $p).Hash.ToLower()}}
$extraTools | ConvertTo-Json | Set-Content "$a\additional-tool-provenance.json"
& 'C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe' -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -format json | Set-Content "$a\vs-discovery.json"
[xml]$e=Get-Content "$a\engine-results.xml" -Raw
[xml]$c=Get-Content "$a\consumer-results.xml" -Raw
$testDetails=foreach($t in $e.testsuite.testcase){@{name=$t.name;status=$t.status;passed=($null -eq $t.failure);internalPassLines=@(($t.'system-out' -split "`n") | Where-Object {$_ -match '^PASS '}).Count}}
$l=Get-Content "$a\lifecycle.json" -Raw | ConvertFrom-Json
$l | Add-Member -NotePropertyName finalFreeBytes -NotePropertyValue ([IO.DriveInfo]::new('C:\').AvailableFreeSpace)
$l | Add-Member -NotePropertyName ownedExistingPaths -NotePropertyValue @($l.ownedPaths | Where-Object {Test-Path -LiteralPath $_})
$l | Add-Member -NotePropertyName evidenceState -NotePropertyValue 'Generated and locally hash-cross-checked; controller bulk retrieval and independent verification pending'
$l | ConvertTo-Json -Depth 8 | Set-Content "$a\lifecycle.json"
@{workspaceRoot=$r;sourceRoot="$r\source";buildRoot="$r\build";revision='2437bea582ef085621adf5b50e628f8ecede8f90'} | ConvertTo-Json | Set-Content "$a\native-environment.json"
@{verdict='success';revision='2437bea582ef085621adf5b50e628f8ecede8f90';timerRevision='38d087f02dc4fb9f00a36d10fbf5ca97e02e2aa9';timerOverride='';platform='Windows x64';configuration='MSVC 19.51.36257.0 Debug static; NMake; VsDevCmd -arch=amd64';engine=@{run=[int]$e.testsuite.tests;passed=5;failed=[int]$e.testsuite.failures;skipped=[int]$e.testsuite.skipped;tests=$testDetails};consumer=@{run=[int]$c.testsuite.tests;passed=1;failed=[int]$c.testsuite.failures;skipped=[int]$c.testsuite.skipped;fixture='extras/miniaudio_cpp_engine/tests/installed_consumer';installedOnly=$true};install=@{success=$true;configuredPrefix="$r\installed prefix"};dependencyFetchInvocations=$fetch.Count;sourceFilesVerified=$before.Count;sourceChanges=$changed;testsRerun=0;omissions=@('Steam Audio SDK not discovered: Windows direct-SDK/instrumented Steam Audio tail tests unavailable. No Linux results asserted here.','macOS pkg-config gate not applicable to Windows','No physical/acoustic or hardware I/O testing');diagnostics=@('Initial local bundle fetch required explicit advertised branch because bundle lacks HEAD.','Timer initial LFS checkout failed for historical benchmark raw data; exact committed pointers retained with process-local GIT_LFS_SKIP_SMUDGE.','CMake 4.4 emitted policy compatibility warnings; NMake ignored inherited parallelism. Logs retained; no suppression or source changes.');timerCancellation='PASS expiry_requests_drain_but_cancellation_does_not';retentionState='retained_pending_evidence';ownedPaths=$l.ownedPaths;evidenceDirectory=$a;manifest='manifest.json; rows exclude manifest.json and manifest.seal.json'} | ConvertTo-Json -Depth 8 | Set-Content "$a\summary.json"
@{category='success';summary='MSVC Debug x64 native engine gates 5/5 and exact installed consumer 1/1 passed; Steam Audio SDK absent.';attemptedPaths=@($r);resolvedExecutables=@{cl='C:\Program Files\Microsoft Visual Studio\2026\BuildTools\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\cl.exe'};selectedEnvironment='VsDevCmd -arch=amd64; MSVC Debug x64';sourceRevision='2437bea582ef085621adf5b50e628f8ecede8f90';remediation=@()} | ConvertTo-Json -Depth 5 | Set-Content "$a\.codex-result.json"
$files=@(Get-ChildItem $a -Recurse -Force -File | Where-Object {$_.Name -notin @('manifest.json','manifest.seal.json')} | Sort-Object { [IO.Path]::GetRelativePath($a,$_.FullName) })
$rows=@(foreach($f in $files){@{path=[IO.Path]::GetRelativePath($a,$f.FullName).Replace('\','/');bytes=$f.Length;sha256=(Get-FileHash -LiteralPath $f.FullName).Hash.ToLower()}})
if(@($rows.path | Select-Object -Unique).Count -ne $rows.Count){throw 'duplicate paths'}
$sum=($rows | Measure-Object bytes -Sum).Sum
@{algorithm='SHA256';rowCount=$rows.Count;payloadBytes=[long]$sum;files=$rows} | ConvertTo-Json -Depth 5 | Set-Content "$a\manifest.json"
$m=Get-Content "$a\manifest.json" -Raw | ConvertFrom-Json
$actual=@(Get-ChildItem $a -Recurse -Force -File | Where-Object {$_.Name -notin @('manifest.json','manifest.seal.json')})
if($actual.Count -ne $m.rowCount -or ($actual | Measure-Object Length -Sum).Sum -ne $m.payloadBytes){throw 'count/byte mismatch'}
foreach($row in $m.files){$f=Get-Item -LiteralPath "$a\$($row.path)";if($f.Length -ne $row.bytes -or (Get-FileHash -LiteralPath $f.FullName).Hash.ToLower() -ne $row.sha256){throw 'manifest mismatch'}}
$seal=@{manifestSha256=(Get-FileHash "$a\manifest.json").Hash.ToLower();rowCount=$m.rowCount;payloadBytes=$m.payloadBytes;uniquePaths=$true;filesystemCountAndBytesMatched=$true;allPayloadHashesRechecked=$true;controllerIndependentVerification='pending'}
$seal | ConvertTo-Json | Set-Content "$a\manifest.seal.json"
$seal | ConvertTo-Json
