$ErrorActionPreference='Stop'
$a='C:\Users\codex-worker\.codex\codex-mcp-server\job-artifacts\5ed2f6c9914b1375\tasks\task-0'
$r='C:\codex-worker\offload\miniaudio-eof-2437bea'
$incoming='C:\codex-worker\offload\incoming'
$free=[IO.DriveInfo]::new('C:\').AvailableFreeSpace
$bundles=@(@{path="$incoming\miniaudio-eof-2437bea.bundle";bytes=1392431;sha256='ff91d2e23bb98c877251c87c6e985745b5bcb643258bf20fdc1f05637563dff2'},@{path="$incoming\timer-miniaudio-eof-2437bea.bundle";bytes=951672;sha256='a781deb2b73b09048b7aeba11f6a032577d5019f59eaa7f893a1be4988d4210d'})
@{identity=@{endpoint='windows-offload';account='win11\codex-worker';job='5ed2f6c9914b1375';task='task-0';identitySource=$a};ownedPaths=@($r,"$r\source","$r\timer","$r\build","$r\installed prefix","$r\consumer")+@($bundles.path);immutableInputs=$bundles;sharedCachesCreated=@();freeBytes=$free;estimatedPeakExtraBytes=2147483648;retentionReason='Await controller bulk retrieval and independent hash verification';evidenceFetchState='pending';independentHashVerification='pending';reviewDate='2026-10-11';cleanupState='retained_pending_evidence';historicalRoots=@{count=4;logicalBytes=1048956819;state='retained; Restart Manager ERROR_ACCESS_DENIED; outside cleanup scope'};originalRepositories='read-only; outside cleanup scope';freeSpaceProbe='System.IO.DriveInfo; Get-Volume CIM access denied'} | ConvertTo-Json -Depth 8 | Set-Content "$a\lifecycle.json"
if($free -lt 2147483648){throw 'Insufficient coexistence space'}
Start-Transcript "$a\staging.log"
Get-Command Get-FileHash
foreach($b in $bundles){$f=Get-Item -LiteralPath $b.path;$h=(Get-FileHash -LiteralPath $b.path -Algorithm SHA256).Hash.ToLower(); if($f.Length -ne $b.bytes -or $h -ne $b.sha256){throw 'Bundle mismatch'}; "$($b.path) $($f.Length) $h"}
& git -C C:\codex-worker\repos\miniaudio-835a14f status --porcelain=v1; if($LASTEXITCODE){throw 'base status failed'}
& git -C C:\codex-worker\repos\miniaudio-835a14f rev-parse HEAD
foreach($b in $bundles){& git -C C:\codex-worker\repos\miniaudio-835a14f bundle verify $b.path;if($LASTEXITCODE){throw 'bundle verify failed'}}
New-Item -ItemType Directory -Path $r | Out-Null
& git clone --no-hardlinks C:\codex-worker\repos\miniaudio-835a14f "$r\source";if($LASTEXITCODE){throw 'clone failed'}
& git -C "$r\source" fetch $bundles[0].path; if($LASTEXITCODE){throw 'fetch failed'}
& git -C "$r\source" checkout --detach 2437bea582ef085621adf5b50e628f8ecede8f90;if($LASTEXITCODE){throw 'checkout failed'}
& git clone $bundles[1].path "$r\timer";if($LASTEXITCODE){throw 'timer clone failed'}
& git -C "$r\timer" checkout --detach 38d087f02dc4fb9f00a36d10fbf5ca97e02e2aa9;if($LASTEXITCODE){throw 'timer checkout failed'}
foreach($p in @("$r\source","$r\timer")){& git -C $p rev-parse HEAD;$s=& git -C $p status --porcelain=v1;if($s){throw "Dirty $p"}}
Stop-Transcript
