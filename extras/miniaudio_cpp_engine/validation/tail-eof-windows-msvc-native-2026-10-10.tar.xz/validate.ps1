$ErrorActionPreference='Stop'
$a='C:\Users\codex-worker\.codex\codex-mcp-server\job-artifacts\5ed2f6c9914b1375\tasks\task-0'
$r='C:\codex-worker\offload\miniaudio-eof-2437bea'
$env:CC='cl';$env:CXX='cl'
$records=[Collections.Generic.List[object]]::new()
function Run($name,$exe,$arguments){
 @{exe=$exe;arguments=$arguments} | ConvertTo-Json -Depth 5 | Set-Content "$a\$name-command.json"
 & $exe @arguments 2>&1 | Tee-Object -FilePath "$a\$name.log" | Out-Host
 $code=$LASTEXITCODE
 $records.Add(@{step=$name;exitCode=$code})
 $records | ConvertTo-Json | Set-Content "$a\steps.json"
 return $code
}
$prov=foreach($name in @('cl','link','lib','nmake','cmake','ctest','git','pwsh')){$p=(Get-Command $name -CommandType Application).Source;$f=Get-Item $p;@{name=$name;path=$f.FullName;version=$f.VersionInfo.FileVersion;sha256=(Get-FileHash $p).Hash.ToLower()}}
@{tools=$prov;platform=[Runtime.InteropServices.RuntimeInformation]::OSDescription;architecture=[Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString();vsInstall=$env:VSINSTALLDIR;vcTools=$env:VCToolsInstallDir;sdk=$env:WindowsSdkDir;sdkVersion=$env:WindowsSDKVersion;CC=$env:CC;CXX=$env:CXX;PATH=$env:PATH;INCLUDE=$env:INCLUDE;LIB=$env:LIB} | ConvertTo-Json -Depth 5 | Set-Content "$a\provenance.json"
& cl 2>&1 | Set-Content "$a\compiler-version.log"
& cmake --version | Set-Content "$a\cmake-version.log"
& git --version | Set-Content "$a\git-version.log"
$opts=@('-S',"$r\source",'-B',"$r\build",'-G','NMake Makefiles','-DCMAKE_C_COMPILER=cl','-DCMAKE_CXX_COMPILER=cl','-DCMAKE_BUILD_TYPE=Debug','-DBUILD_SHARED_LIBS=OFF','-DMINIAUDIO_BUILD_CPP_ENGINE=ON','-DMINIAUDIO_BUILD_TESTS=ON','-DMINIAUDIO_CPP_ENGINE_BUILD_ALLOCATION_TESTS=ON','-DMINIAUDIO_CPP_ENGINE_BUILD_BENCHMARKS=OFF','-DMINIAUDIO_INSTALL=ON','-DMINIAUDIO_NO_EXTRA_NODES=ON','-DMINIAUDIO_NO_LIBOPUS=ON','-DMINIAUDIO_NO_LIBVORBIS=ON','-DMINIAUDIO_FETCH_LIBOPUS=OFF','-DMINIAUDIO_FETCH_LIBVORBIS=OFF','-DMINIAUDIO_ENABLE_ONLY_SPECIFIC_BACKENDS=ON','-DMINIAUDIO_ENABLE_NULL=ON',"-DMINIAUDIO_CPP_ENGINE_TIMER_WHEELS_SOURCE_DIR=$r\timer","-DCMAKE_INSTALL_PREFIX=$r\installed prefix",'-DCMAKE_INSTALL_LIBDIR=lib','--trace-expand','--trace-format=json-v1',"--trace-redirect=$a\configure-trace.jsonl")
if((Run 'configure' 'cmake' $opts) -ne 0){exit 1}
Copy-Item "$r\build\CMakeCache.txt" "$a\engine-CMakeCache.txt"
$targets=@('miniaudio_cpp_engine_tests','miniaudio_cpp_engine_stream_tests','miniaudio_cpp_engine_allocation_tests','miniaudio_cpp_engine_timer_wheels_tests','miniaudio')
if(Select-String -Path "$r\build\extras\miniaudio_cpp_engine\CTestTestfile.cmake" -Pattern 'add_test\(miniaudio_cpp_engine_steamaudio ' -Quiet){$targets+='miniaudio_cpp_engine_steamaudio_tests'}
if((Run 'build' 'cmake' (@('--build',"$r\build",'--config','Debug','--target')+$targets)) -ne 0){exit 2}
$null=Run 'engine-tests' 'ctest' @('--test-dir',"$r\build",'--output-on-failure','-R','^miniaudio_cpp_engine','--output-junit',"$a\engine-results.xml")
$null=Run 'engine-inventory' 'ctest' @('--test-dir',"$r\build",'--show-only=json-v1','-R','^miniaudio_cpp_engine')
Copy-Item "$r\build\Testing\Temporary\LastTest.log" "$a\engine-LastTest.log"
if((Run 'install' 'cmake' @('--install',"$r\build",'--config','Debug')) -ne 0){exit 3}
Copy-Item "$r\build\install_manifest.txt" "$a\install-files.txt"
if((Run 'consumer-configure' 'cmake' @('-S',"$r\source\extras\miniaudio_cpp_engine\tests\installed_consumer",'-B',"$r\consumer",'-G','NMake Makefiles','-DCMAKE_CXX_COMPILER=cl','-DCMAKE_BUILD_TYPE=Debug',"-DMINIAUDIO_TEST_INSTALL_PREFIX=$r\installed prefix")) -ne 0){exit 4}
Copy-Item "$r\consumer\CMakeCache.txt" "$a\consumer-CMakeCache.txt"
if((Run 'consumer-build' 'cmake' @('--build',"$r\consumer",'--config','Debug','--verbose')) -ne 0){exit 5}
$null=Run 'consumer-tests' 'ctest' @('--test-dir',"$r\consumer",'--output-on-failure','--output-junit',"$a\consumer-results.xml")
Copy-Item "$r\consumer\Testing\Temporary\LastTest.log" "$a\consumer-LastTest.log"
