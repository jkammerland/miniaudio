import pathlib,subprocess,json,hashlib,os,sys,shutil
A=pathlib.Path('/Users/ai-dev/.codex/codex-mcp-server/job-artifacts/2d78782e802f5c36/tasks/task-0'); R=pathlib.Path('/Users/ai-dev/offload/miniaudio-eof-2437bea'); S=R/'source'; T=R/'timer'; B=R/'build'; I=R/'installed prefix'; C=R/'consumer'; BASE='/Users/ai-dev/repos/miniaudio-835a14f'
def save(n,x): (A/n).write_text(json.dumps(x,indent=2)+'\n')
def run(n,args,cwd=None):
 p=subprocess.run([str(a) for a in args],cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (A/(n+'.log')).write_text(p.stdout)
 with (A/'commands.jsonl').open('a') as f: f.write(json.dumps({'name':n,'argv':[str(a) for a in args],'cwd':str(cwd) if cwd else os.getcwd(),'exitCode':p.returncode})+'\n')
 print(n,p.returncode,p.stdout[-1800:],flush=True)
 if p.returncode: raise RuntimeError(n+' failed')
 return p.stdout
if __name__=='__main__':
 l=json.loads((A/'lifecycle.json').read_text())
 for j,b in enumerate(l['immutableInputBundles']):
  p=pathlib.Path(b['path']); assert p.stat().st_size==b['bytes']; assert hashlib.sha256(p.read_bytes()).hexdigest()==b['sha256']; run('bundle-verify-'+str(j),['git','bundle','verify',p],BASE)
 l['inputVerification']='size, SHA256 and git bundle verify passed'; save('lifecycle.json',l)
 assert run('base-head',['git','rev-parse','HEAD'],BASE).strip()=='835a14fc28a14d96c54f6932ee6121acfcd58a90'
 assert not run('base-status-before',['git','status','--porcelain=v1','--untracked-files=all'],BASE).strip()
 assert not R.exists(); R.mkdir()
 run('clone-source',['git','clone','--no-hardlinks',BASE,S]); run('fetch-source',['git','fetch',l['immutableInputBundles'][0]['path']],S); run('checkout-source',['git','checkout','--detach','2437bea582ef085621adf5b50e628f8ecede8f90'],S)
 run('clone-timer',['git','clone',l['immutableInputBundles'][1]['path'],T]); run('checkout-timer',['git','checkout','--detach','38d087f02dc4fb9f00a36d10fbf5ca97e02e2aa9'],T)
 for name,p,rev in [('source',S,'2437bea582ef085621adf5b50e628f8ecede8f90'),('timer',T,'38d087f02dc4fb9f00a36d10fbf5ca97e02e2aa9')]:
  assert run(name+'-head',['git','rev-parse','HEAD'],p).strip()==rev
  assert not run(name+'-status-before',['git','status','--porcelain=v1','--untracked-files=all'],p).strip()
