from validate import *
pro={}
for n,p,args in [('cmake','/opt/homebrew/bin/cmake',['--version']),('ninja','/opt/homebrew/bin/ninja',['--version']),('cc','/usr/bin/clang',['--version']),('cxx','/usr/bin/clang++',['--version']),('pkg-config','/opt/homebrew/bin/pkg-config',['--version']),('ctest','/opt/homebrew/bin/ctest',['--version']),('xcrun','/usr/bin/xcrun',['--version']),('git',shutil.which('git'),['--version'])]:
 q=pathlib.Path(p).resolve(); pro[n]={'path':p,'canonicalPath':str(q),'sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'version':run('version-'+n,[p]+args)}
for n,args in [('platform',['uname','-a']),('macos',['sw_vers']),('xcode',['xcodebuild','-version']),('developer-directory',['xcode-select','-p']),('sdk',['xcrun','--show-sdk-path']),('selected-compiler',['xcrun','--find','clang++'])]: pro[n]=run(n,args)
save('provenance.json',pro)
rows=[]
for name,p in [('source',S),('timer',T)]:
 files=subprocess.check_output(['git','ls-files','-z'],cwd=p).decode().split('\0')
 for f in sorted(filter(None,files)):
  q=p/f
  if q.is_file(): rows.append({'repository':name,'path':f,'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()})
save('source-hashes-before.json',rows)
opts={'CMAKE_BUILD_TYPE':'Release','CMAKE_OSX_ARCHITECTURES':'arm64','CMAKE_C_COMPILER':'/usr/bin/clang','CMAKE_CXX_COMPILER':'/usr/bin/clang++','CMAKE_MAKE_PROGRAM':'/opt/homebrew/bin/ninja','CMAKE_INSTALL_PREFIX':str(I),'CMAKE_EXPORT_COMPILE_COMMANDS':'ON','BUILD_SHARED_LIBS':'OFF','MINIAUDIO_BUILD_CPP_ENGINE':'ON','MINIAUDIO_BUILD_TESTS':'ON','MINIAUDIO_CPP_ENGINE_BUILD_ALLOCATION_TESTS':'ON','MINIAUDIO_CPP_ENGINE_BUILD_BENCHMARKS':'OFF','MINIAUDIO_INSTALL':'ON','MINIAUDIO_NO_EXTRA_NODES':'ON','MINIAUDIO_NO_LIBOPUS':'ON','MINIAUDIO_NO_LIBVORBIS':'ON','MINIAUDIO_FETCH_LIBOPUS':'OFF','MINIAUDIO_FETCH_LIBVORBIS':'OFF','MINIAUDIO_ENABLE_ONLY_SPECIFIC_BACKENDS':'ON','MINIAUDIO_ENABLE_NULL':'ON','MINIAUDIO_CPP_ENGINE_TIMER_WHEELS_SOURCE_DIR':str(T)}
run('configure',['/opt/homebrew/bin/cmake','-S',S,'-B',B,'-G','Ninja']+['-D'+k+'='+v for k,v in opts.items()])
shutil.copyfile(B/'CMakeCache.txt',A/'engine-CMakeCache.txt')
run('registered-engine-tests',['/opt/homebrew/bin/ctest','--test-dir',B,'--show-only=json-v1','-R','^miniaudio_cpp_engine'])
