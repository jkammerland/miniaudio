from validate import *
import xml.etree.ElementTree as ET,shlex
for name,p in [('source',S),('timer',T),('base',pathlib.Path(BASE))]:
 assert not run(name+'-status-after',['git','status','--porcelain=v1','--untracked-files=all'],p).strip()
 run(name+'-head-after',['git','rev-parse','HEAD'],p)
rows=json.loads((A/'source-hashes-before.json').read_text())
for r in rows:
 p={'source':S,'timer':T}[r['repository']]/r['path']; assert p.stat().st_size==r['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
save('source-integrity-after.json',{'trackedFilesVerified':len(rows),'allHashesMatchBefore':True,'sourceClean':True,'timerClean':True,'baseClean':True})
for src,dst in [(B/'compile_commands.json','engine-compile_commands.json'),(C/'compile_commands.json','consumer-compile_commands.json'),(C/'CMakeCache.txt','consumer-CMakeCache.txt'),(B/'install_manifest.txt','install_manifest.txt')]: shutil.copyfile(src,A/dst)
for p in (I/'lib/pkgconfig').glob('*.pc'): shutil.copyfile(p,A/('installed-'+p.name))
cache=(B/'CMakeCache.txt').read_text()
assert 'MINIAUDIO_CPP_ENGINE_TIMER_WHEELS_REVISION_OVERRIDE:STRING=\n' in cache
assert 'MINIAUDIO_CPP_ENGINE_VERIFY_TIMER_WHEELS_REVISION:BOOL=ON' in cache
assert 'CMAKE_INSTALL_PREFIX:PATH='+str(I)+'\n' in cache
assert 'MINIAUDIO_ENABLE_COREAUDIO:BOOL=OFF' in cache
commands=json.loads((C/'compile_commands.json').read_text()); includes=[]
for entry in commands:
 tokens=shlex.split(entry['command'])
 for j,t in enumerate(tokens):
  if t in ['-I','-isystem']: includes.append(tokens[j+1])
  elif t.startswith('-I'): includes.append(t[2:])
assert includes and all(str(I) in p for p in includes)
linklog=(A/'consumer-build.log').read_text()
assert str(I/'lib/libminiaudio.a') in linklog and str(I/'lib/libminiaudio_cpp_engine.a') in linklog
save('consumer-isolation.json',{'fixture':str(S/'extras/miniaudio_cpp_engine/tests/installed_consumer'),'miniaudioIncludePaths':includes,'installedArchives':[str(I/'lib/libminiaudio.a'),str(I/'lib/libminiaudio_cpp_engine.a')],'pkgConfigStatic':True,'sourceOrBuildMiniaudioIncludePaths':False,'sameCompiler':'/usr/bin/clang++','verified':True})
pro=json.loads((A/'provenance.json').read_text())
for n in ['clang','clang++']:
 p=pathlib.Path(run('xcrun-resolve-'+n,['/usr/bin/xcrun','--find',n]).strip()); q=p.resolve(); pro['actual-'+n]={'path':str(p),'canonicalPath':str(q),'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()}
save('provenance.json',pro)
executables=sorted((B/'extras/miniaudio_cpp_engine').glob('*_tests'))+[C/'installed_consumer']; ids=[]
for p in executables:
 ids.append({'path':str(p),'canonicalPath':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'identity':run('identity-'+p.name,['/usr/bin/file',p]),'linkedLibraries':run('linked-'+p.name,['/usr/bin/otool','-L',p])})
save('executable-identities.json',ids)
installed=[]
for p in sorted(I.rglob('*')):
 if p.is_file(): installed.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
save('installed-identities.json',installed)
run('contract-evidence',['rg','-n','playback_device_test_access|data_callback|expiry_requests_drain|timer cancellation requested a drain',S/'extras/miniaudio_cpp_engine/tests/stream_tests.cpp',S/'extras/miniaudio_cpp_engine/tests/timer_wheels_tests.cpp',S/'extras/miniaudio_cpp_engine/include/miniaudio_cpp_engine/device_adapter.hpp'])
results={}
for n in ['engine','consumer']:
 root=ET.parse(A/(n+'-ctest.xml')).getroot(); cases=root.findall('testcase'); passed=[c.attrib['name'] for c in cases if c.find('failure') is None and c.find('skipped') is None and c.attrib.get('status')=='run']; assert len(passed)==len(cases)
 results[n]={'run':len(cases),'passed':len(passed),'failed':0,'tests':passed,'invocations':1}
assert results['engine']['run']==6 and results['consumer']['run']==1
l=json.loads((A/'lifecycle.json').read_text()); l.update({'freeBytesAfterValidation':os.statvfs(R).f_bavail*os.statvfs(R).f_frsize,'evidenceHashState':'internal manifest generated and independently reread locally; controller verification pending','cleanupState':'retained_pending_evidence','cleanupPerformed':False,'ownedArtifactDirectory':str(A),'ownedInputPaths':[b['path'] for b in l['immutableInputBundles']]}); save('lifecycle.json',l)
save('summary.json',{'verdict':'success','revision':'2437bea582ef085621adf5b50e628f8ecede8f90','timerRevision':'38d087f02dc4fb9f00a36d10fbf5ca97e02e2aa9','timerRevisionOverride':'','platform':'macOS 26.5.2 arm64','configuration':'Release static, Apple Clang 21, null-only','results':results,'install':'passed at configured prefix containing a space','consumerIsolation':'verified installed headers and static archives via installed pkg-config metadata','timerCancellationDoesNotRequestDrain':'passed','streamUsesActualPlaybackCallbackThroughFriendAccess':True,'sourceIntegrity':'all tracked hashes unchanged, all three repositories clean','omissions':['Steam Audio SDK not discovered: native direct-SDK and instrumented Steam Audio tail tests unavailable on this host; separate Linux evidence not evaluated here','Physical/acoustic/hardware I/O testing excluded by request'],'testFailures':[],'nonTestIncident':{'command':'fetch-source','exitCode':128,'diagnosis':'Bundle advertises branch but no HEAD; fetch with explicit advertised branch succeeded. No tests retried.'},'buildWarnings':['Unused static ma_device__on_notification_rerouted in null-only build'],'optionalDependencyDiscovered':'SDL2 /opt/homebrew/lib/libSDL2.dylib; not linked to engine gates','retainedOwnedPaths':l['ownedPaths']+l['ownedInputPaths']+[str(A)],'cleanupState':'retained_pending_evidence'})
save('.codex-result.json',{'category':'success','summary':'Native engine gates 6/6 and installed consumer 1/1 passed; Steam Audio SDK absent. Exact clean revisions verified.','attemptedPaths':[str(R)],'resolvedExecutables':{k:v['canonicalPath'] for k,v in pro.items() if isinstance(v,dict) and 'canonicalPath' in v},'selectedEnvironment':'mac-offload, macOS arm64 Release Apple Clang','sourceRevision':'2437bea582ef085621adf5b50e628f8ecede8f90','remediation':[]})
files=sorted(p for p in A.rglob('*') if p.is_file() and p.name not in ['manifest.json','manifest.sha256'])
manifestRows=[{'path':p.relative_to(A).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
assert len({r['path'] for r in manifestRows})==len(files)
m={'algorithm':'SHA256','rowCount':len(files),'payloadBytes':sum(r['bytes'] for r in manifestRows),'files':manifestRows}; save('manifest.json',m)
# Re-read the filesystem and serialized manifest before sealing.
m=json.loads((A/'manifest.json').read_text()); actual=sorted(p.relative_to(A).as_posix() for p in A.rglob('*') if p.is_file() and p.name not in ['manifest.json','manifest.sha256'])
assert actual==[r['path'] for r in m['files']]; assert len(actual)==m['rowCount']; assert sum((A/r['path']).stat().st_size for r in m['files'])==m['payloadBytes']
for r in m['files']: assert hashlib.sha256((A/r['path']).read_bytes()).hexdigest()==r['sha256']
digest=hashlib.sha256((A/'manifest.json').read_bytes()).hexdigest(); (A/'manifest.sha256').write_text(digest+'  manifest.json\n'); print('SEALED',digest,m['rowCount'],m['payloadBytes'])
